package net.jarlehansen.proto2javame.business.sourcebuilder.staticmethods;

/**
 * 
 * @author hansjar@gmail.com Jarle Hansen
 *
 */
public interface StaticMethodsBuilder {
	public StringBuilder createStaticMethods(final String className);
}
