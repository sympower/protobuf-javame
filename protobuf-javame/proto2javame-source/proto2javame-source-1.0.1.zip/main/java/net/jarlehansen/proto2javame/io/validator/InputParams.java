package net.jarlehansen.proto2javame.io.validator;

/**
 * 
 * @author hansjar@gmail.com Jarle Hansen
 *
 */
enum InputParams {
	;
	
	public static final String JAVA_OUT_TAG = "--java_out=";
	public static final int VALID_NUMBER_OF_PARAMS = 2;
}
