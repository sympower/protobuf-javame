package net.jarlehansen.protobuf.javame.input.taghandler;

public interface UnknownTagHandler {
	public void unknownTag(final String unknownTag);
}
