package net.jarlehansen.protobuf.javame.input.taghandler;

public interface ParentReader {
	public void setUnknownField(final int field);
}
